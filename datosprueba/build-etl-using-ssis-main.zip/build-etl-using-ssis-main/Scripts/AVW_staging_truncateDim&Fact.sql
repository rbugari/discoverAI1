# Code using in Execute SQL Task (SSIS)

TRUNCATE TABLE Dim_Territory
TRUNCATE TABLE Dim_ProductCategory
TRUNCATE TABLE Dim_ProductSubCategory
TRUNCATE TABLE Dim_Product
TRUNCATE TABLE Dim_Date
TRUNCATE TABLE Dim_SalesPerson
TRUNCATE TABLE Fact_SalesOrder
TRUNCATE TABLE Fact_Product
